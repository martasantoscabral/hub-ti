
/**
 * Representa um jogo genérico baseado em colunas, composto por uma grelha
 * e peças que caem verticalmente.  
 * Todos os tipos de jogos concretos (como SingleScoreGame e MultipleRewardGame)
 * devem implementar este interface.
 *
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */

import java.util.List;

public interface Game {

	/**
     * Tamanho fixo das peças
     */
    int SIZE_OF_PIECE = 3;
  
    /**
     * Número de linhas da grelha de jogo.
     * @return número total de linhas da grelha
     */
    int linesInGrid();                
    

    /**
     * Número de colunas da grelha de jogo.
     * @param n número de permutações a aplicar
     * @requires n > 0 
     * @return número total de colunas da grelha
     */
    int colsInGrid();                 
    																               	

    /**
     * roda/permutar a peça atual n vezes
     *  @param n número de permutações a aplicar
     * @requires  n > 0
     */    															

    void permutatePiece(int n);        
    																			   		
    
    /**
     * largar a peça na coluna col (1..n)
     * @param col coluna de destino (índice começa em 1)
     * @requires 1 <= col <= colsInGrid()
     */
    void placePiece(int col);          


    /**
     * criar nova peça aleatória
     */  
    void generatePiece();              


    /**
     * espaço livre numa coluna (em nº de células)
     * @param col coluna a verificar (índice começa em 1)
     * @requires 1 <= col <= colsInGrid()
     * @return número de posições vazias consecutivas no topo da coluna
     */
    int spaceInColumn(int col);        
    
    
    /**
     * o jogo já acabou?
     * @return true se o jogo não puder continuar, false caso contrário
     */
    boolean finished();               
    

    /**
     * representação textual da peça atual
     * @return cadeia de texto que representa a peça atual
     */
    String currentPiece();             
    

    /**
     * regista pontuação da jogada
     * @param eliminated lista com o número de elementos eliminados em cada ronda
     * @requires eliminated != null
     */
    void registerPlayScore(List<Integer> eliminated); 


    /**
     * devolve o score atual
     * @return pontuação atual
     */
    int score();                      
}
