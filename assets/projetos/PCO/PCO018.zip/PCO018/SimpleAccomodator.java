
/**
 * Implementa um acomodador simples.
 * Dada uma sequência que representa uma coluna (de cima para baixo), Todos os símbolos “caiam” para o fundo, fechando os buracos representados por {@code nothing}.
 * No fim, todas as posições vazias ficam concentradas no topo da coluna.
 *
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */

public class SimpleAccomodator implements Accomodator {
	

    /**
     * Cria um SimpleAccomodator sem estado adicional.
     * Este acomodador aplica regras simples para fazer cair símbolos
     * após eliminações.
     */
    public SimpleAccomodator() {
    }
    
  //--------------------------------------------------------------------------------------------------------------------

    /**
     * Acomoda os símbolos da sequência dada, fazendo-os cair para o fundo e juntando todos os buracos (símbolos {@code nothing}) no topo.
     * @param sequence sequência de símbolos a acomodar
     * @param nothing símbolo que representa “vazio” ou buraco
     *
     * @requires sequence != null
     * @requires nothing != null
     */
    
    @Override
    public void accomodate(Symbol[] sequence, Symbol nothing) {
        if (sequence == null || nothing == null) {
            throw new IllegalArgumentException();
        }

        // sequência representa uma coluna de cima (0) para baixo (length-1)
        // objetivo: tudo o que não é nothing desce para o fundo

        int write = sequence.length - 1;

        // copiar símbolos não vazios para o fundo, mantendo ordem relativa
        for (int i = sequence.length - 1; i >= 0; i--) {
            if (sequence[i] != nothing) {
                sequence[write] = sequence[i];
                write--;
            }
        }

        // preencher o resto (no topo) com nothing
        for (int i = write; i >= 0; i--) {
            sequence[i] = nothing;
        }
    }
}
