
/**
 * Elimina símbolos numa dada sequência, de acordo com as regras
 * da implementação concreta.
 * 
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */


public interface Eliminator {

    /**
    * Elimina símbolos na sequência dada, substituindo-os por {@code nothing}.
    *
    * @param seq sequência de símbolos onde vão ser feitas eliminações
    * @param blockSize tamanho mínimo de um grupo ou padrão a eliminar
    * @param nothing símbolo que representa "vazio" ou posição eliminada
    * @requires seq != null
    * @requires nothing != null
    * @requires blockSize > 0
    * @return número total de símbolos eliminados na sequência
    */

    int eliminateSequence(Symbol[] seq, int blockSize, Symbol nothing);
}
