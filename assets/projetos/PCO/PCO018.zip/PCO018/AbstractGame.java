

import java.util.List;
import java.util.Random;

/**
 * Classe base para os vários tipos de jogos.
 * Implementa quase tudo da interface Game e deixa a pontuação para as subclasses (SingleScoreGame, MultipleRewardGame).
 * 
 * @author Grupo 18– Marta Cabral (64686), Camile Hasse (64178)
 * 
 */


public abstract class AbstractGame implements Game {

    // Usado no PCOMain: AbstractGame.SIZE_OF_PIECE
    public static final int SIZE_OF_PIECE = Game.SIZE_OF_PIECE;

    // ---- Atributos comuns a todos os jogos ----
    protected PlayArea area;       		 // zona onde as peças caem e onde ocorrem eliminações
    protected Piece currentPiece; 		 // peça atualmente em jogo
    protected Random generator;     	 // gerador aleatório
    protected Symbol emptySymbol; 		 // símbolo "vazio"
    protected Symbol[] values;    		 // símbolos possíveis no jogo

    protected int currentScore;          // pontuação atual/acumulada


    /**
     * Constrói um jogo genérico com uma área de jogo, símbolos e objetos responsáveis por eliminar e acomodar símbolos.
     *
     * @param nRows número de linhas da grelha
     * @param nCols número de colunas da grelha
     * @param difficulty número de linhas já preenchidas no início
     * @param empty símbolo que representa vazio
     * @param symbols conjunto de símbolos possíveis
     * @param gen gerador de números aleatórios
     * @param elim objeto responsável pelas eliminações
     * @param acc objeto responsável pelas acomodações
     *
     * @requires nRows > 0 && nCols > 0
     * @requires empty != null && symbols != null
     * @requires gen != null && elim != null && acc != null
     */  
    public AbstractGame(int nRows, int nCols, int difficulty,
                        Symbol empty, Symbol[] symbols,
                        Random gen, Eliminator elim, Accomodator acc) {

        this.emptySymbol = empty;
        this.values = symbols;
        this.generator = gen;
        this.currentScore = 0;

        // cria a área de jogo com as regras definidas pelo eliminador e acomodador
        this.area = new PlayArea(nRows, nCols, difficulty,
                                 empty, symbols, gen, elim, acc);

        this.currentPiece = null;  // Ainda não há peça em jogo
    }
 
 // ---------------------------- Métodos que apenas delegam para PlayArea / Piece ---------------------------------------
    /**
     * Devolve o número de linhas da grelha.
     */
    public int linesInGrid() {
        // gridDimensions()[0] = número de linhas
        return area.gridDimensions()[0];
    }

  //--------------------------------------------------------------------------------------------------------------------  
    
    /**
     * Devolve o número de colunas da grelha.
     */
    public int colsInGrid() {
        // gridDimensions()[1] = número de colunas
        return area.gridDimensions()[1];
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /** 
     * Permuta a peça atual n vezes. Se ainda não houver peça, não faz nada.
     *  @requires n > 0
     */
    public void permutatePiece(int n) {
        // Se houver peça e n > 0, pedimos à peça para se permutar n vezes
        if (currentPiece != null && n > 0) {
            currentPiece.permutation(n);
        }
    }  
    
//----------------------------------------------------------------------------------------------------------------------    
    
    /**
     * Coloca a peça na coluna indicada (1 a N).  
     * Após a colocação, trata automaticamente das eliminações e acomodações necessárias.
     *
     * @param col coluna de destino
     *
     * @requires currentPiece != null
     * @requires 1 <= col <= colsInGrid()
     */
  
    public void placePiece(int col) {
        // Se não houver peça atual, não faz nada
        if (currentPiece == null) {
            return;
        }
        int realCol = col - 1; 						// conversão para índice interno
        area.placePiece(currentPiece, realCol);     // Coloca a peça na PlayArea

        List<Integer> eliminated = area.eliminateAccomodateAll(SIZE_OF_PIECE); // Depois de colocar, faz todas as eliminações + acomodações necessárias

        registerPlayScore(eliminated);  		    // Cada tipo de jogo regista a pontuação à sua maneira
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Gera uma nova peça aleatória do tamanho correto.
     */
    public void generatePiece() {
        // Cria uma nova peça aleatória com SIZE_OF_PIECE símbolos
        currentPiece = new Piece(generator, SIZE_OF_PIECE, emptySymbol, values);
    }
    
  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Devolve o número de espaços vazios no topo de uma coluna.
     * @param col coluna (1 a N)
     * @requires 1 <= col <= colsInGrid()
     */
    public int spaceInColumn(int col) {
        // Converte coluna 1-based (utilizador) para 0-based (PlayArea)
        int realCol = col - 1;
        return area.spaceInColumn(realCol);
    }
    
  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Define se o jogo terminou.  
     * Aqui, um jogo base termina quando já não há espaço para peças.
     * Jogos concretos podem alterar este comportamento.
     * @return true se não houver espaço para continuar a jogar
     */
    public boolean finished() {
        // Jogo termina quando já não existe nenhuma coluna
        // onde caiba uma peça inteira
        return !area.hasEnoughSpace(SIZE_OF_PIECE);
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Mostra a peça atual em formato de texto.
     * @return representação textual da peça atual
     */
    public String currentPiece() {
        if (currentPiece == null) {
            return "No current piece" + System.lineSeparator();
        }
        return currentPiece.toString();
    }

  //--------------------------------------------------------------------------------------------------------------------
 
    /**
     * Indica se toda a grelha está vazia.  
     * Usado por alguns tipos de jogo, como o SingleScoreGame.
     * @return true se todas as colunas estiverem completamente vazias
     */
    protected boolean gridIsEmpty() {
        int rows = linesInGrid();
        int cols = colsInGrid();

        for (int c = 0; c < cols; c++) {
            // se o nº de posições vazias numa coluna for diferente do nº de linhas,
            // então essa coluna não está totalmente vazia
            if (area.spaceInColumn(c) != rows) {
                return false;
            }
        }
        return true;
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Cada jogo concreto deve indicar como regista a pontuação.
     * @param eliminated lista com o número de elementos eliminados em cada ronda
     */
    public abstract void registerPlayScore(List<Integer> eliminated);

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Devolve a pontuação atual, definida pelo jogo concreto.
     */
    public abstract int score();

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Representação textual do estado do jogo: mostra primeiro a grelha e depois a peça atual.
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Primeiro a grelha atual
        sb.append(area.currentGrid());

        // Depois a peça atual
        sb.append("Current piece:").append(System.lineSeparator());
        if (currentPiece != null) {
            sb.append(currentPiece.toString());
        } else {
            sb.append("None").append(System.lineSeparator());
        }

        return sb.toString();
    }
}
