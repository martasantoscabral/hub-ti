
/**
 * Eliminador simples:
 * Percorre uma sequência e remove todas as séries de símbolos iguais (consecutivos) com tamanho maior ou igual a blockSize.
 * 
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */
public class SimpleEliminator implements Eliminator {

    /**
     * Cria um SimpleEliminator sem estado adicional.
     * Este eliminador aplica as regras simples de eliminação definidas
     * pela implementação concreta.
     *
     */

    public SimpleEliminator() {
        // nada a fazer no construtor
    }
  //--------------------------------------------------------------------------------------------------------------------
      
    /**
     * Elimina, no array {@code sequence}, todas as sequências de símbolos
     * iguais (diferentes de {@code nothing}) com comprimento >= blockSize.
     * Cada símbolo eliminado é substituído por {@code nothing}.
     *
     * @param sequence array de símbolos onde vão ser feitas as eliminações
     * @param blockSize tamanho mínimo de uma sequência a eliminar
     * @param nothing símbolo que representa “vazio” ou posição eliminada
     * @requires sequence != null
     * @requires nothing != null
     * @requires blockSize > 0   
     * @return número total de símbolos eliminados
     */    

    @Override
    public int eliminateSequence(Symbol[] sequence, int blockSize, Symbol nothing) {
        if (sequence == null || nothing == null || blockSize <= 0) {
            throw new IllegalArgumentException();
        }

        int eliminated = 0;
        int i = 0;

        while (i < sequence.length) {

            Symbol current = sequence[i];

            // "buracos" não contam para sequências
            if (current == nothing) {
                i++;
                continue;
            }

            // conta quantos símbolos iguais seguidos existem a partir de i
            int j = i + 1;
            while (j < sequence.length && sequence[j] == current) {
                j++;
            }

            int runLength = j - i;

            // se o tamanho da sequência for suficiente, elimina tudo
            if (runLength >= blockSize) {
                for (int k = i; k < j; k++) {
                    sequence[k] = nothing;
                }
                eliminated += runLength;
            }

            // salta para depois desta sequência
            i = j;
        }

        return eliminated;
    }
}
