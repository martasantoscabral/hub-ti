
/**
 * Jogo onde o jogador ganha dois tipos de pontos:
 * - pontos por cada jogada feita;
 * - pontos pelos símbolos eliminados.
 *
 * No final, o jogo mostra separadamente:
 * - o total ganho pelas jogadas;
 * - o total ganho pelas eliminações.
 *
 * A pontuação final é a soma destes dois valores.
 * 
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */

import java.util.List;
import java.util.Random;

public class MultipleRewardGame extends AbstractGame {

    // Pontos das jogadas (10 por jogada válida)
    private int playScore;

    // Pontos das eliminações (bónus da Nota 1)
    private int eliminationScore;


    /**
     * Cria um jogo do tipo MultipleRewardGame com a dimensão e dificuldade dadas.
     * @param r número de linhas da grelha
     * @param c número de colunas da grelha
     * @param diff número de linhas iniciais já preenchidas
     * @param empty símbolo que representa vazio
     * @param values conjunto de símbolos possíveis
     * @param gen gerador de números aleatórios
     * @param elim eliminador a usar neste jogo
     * @param acc acomodador a usar neste jogo
     * @requires r > 0 && c > 0
     * @requires empty != null && values != null
     * @requires gen != null && elim != null && acc != null
     */
    public MultipleRewardGame(int r, int c, int diff, Symbol empty, Symbol[] values, Random gen, Eliminator elim, Accomodator acc) {
        super(r, c, diff, empty, values, gen, elim, acc);
        this.playScore = 0;
        this.eliminationScore = 0;
    }



 //--------------------------------------------------------------------------------------------------------------------

    /**
     * Atualiza os pontos da jogada e os pontos pelas eliminações.
     * Cada jogada vale sempre 10 pontos.
     * As eliminações dão pontos extra dependendo do tamanho da cadeia.
     */
    
    @Override
    public void registerPlayScore(List<Integer> eliminated) {
       
        playScore += 10;// 10 pontos por cada jogada válida

        if (eliminated == null) {
            return;
        }

        // Para cada "ronda" de eliminações na mesma jogada
        for (int i = 0; i < eliminated.size(); i++) {
            int nrEliminated = eliminated.get(i);

            // Ignora rondas sem eliminação
            if (nrEliminated <= 0) {
                continue;
            }

            //  Regras de pontuação:
            // 3 símbolos -> 200 pontos
            // cada símbolo extra → +50 pontos
            int base = 200 + (nrEliminated - SIZE_OF_PIECE) * 50;

            // multiplicador de cadeia: 1x, 2x, 3x, ...
            int multiplier = i + 1;

            eliminationScore += base * multiplier;
        }
    }

      
 //--------------------------------------------------------------------------------------------------------------------
 
    /**
     * Devolve a pontuação total.
     */
    
    @Override
    public int score() {
        // Pontuação total (se alguém usar score())
        return playScore + eliminationScore;
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Devolve só os pontos das jogadas.
     */   
    
    public int scoreOfPlays() {
        return playScore;
    }

  //--------------------------------------------------------------------------------------------------------------------
 
    /**
     * Devolve só os pontos das eliminações.
     */

    public int scoreOfEliminations() {
        return eliminationScore;
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Mostra a grelha, a peça atual e as duas pontuações separadas.
     */    
    
    @Override
    public String toString() {
        // Usa a representação base (grelha + peça)
        // e acrescenta as duas pontuações como no ficheiro de outputs.
        return super.toString()
                + "Score of plays: " + playScore
                + "   Score of eliminations: " + eliminationScore
                + System.lineSeparator();
    }
}

