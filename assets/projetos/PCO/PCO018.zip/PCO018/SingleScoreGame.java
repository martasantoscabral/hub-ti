
/**
 * Jogo em que cada jogada válida vale sempre o mesmo número de pontos.
 * O jogo termina quando a grelha fica totalmente vazia ou quando já não há espaço em nenhuma coluna para colocar uma nova peça.
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 */

import java.util.List;
import java.util.Random;

public class SingleScoreGame extends AbstractGame {

	/**
     * Cria um jogo do tipo SingleScoreGame com a dimensão e dificuldade dadas.
     * @param r número de linhas da grelha
     * @param c número de colunas da grelha
     * @param diff número de linhas iniciais já preenchidas
     * @param empty símbolo que representa vazio
     * @param values conjunto de símbolos possíveis
     * @param gen gerador de números aleatórios
     * @param elim eliminador a usar neste jogo
     * @param acc acomodador a usar neste jogo
     *
     * @requires r > 0 && c > 0
     * @requires empty != null && values != null
     * @requires gen != null && elim != null && acc != null
     */

    public SingleScoreGame(int r, int c, int diff, Symbol empty,
                           Symbol[] values, Random gen,
                           Eliminator elim, Accomodator acc) {
        // Delega toda a construção para o AbstractGame
        super(r, c, diff, empty, values, gen, elim, acc);
    }

 //--------------------------------------------------------------------------------------------------------------------  
    
    /**
     * Regista a pontuação de uma jogada.
     * Cada jogada válida vale sempre 10 pontos, independentemente do número de símbolos eliminados.
     * @param eliminated lista com o número de símbolos eliminados em cada ronda (não é usada neste jogo
     * @requires eliminated != null
     */
    public void registerPlayScore(List<Integer> eliminated) {
        // Neste jogo só conta ter feito uma jogada válida
        // (10 pontos por jogada), ignorando quantos símbolos foram eliminados.
        currentScore += 10;
    }
    
  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Devolve a pontuação atual do jogo.
     * @return pontuação acumulada até ao momento
     */
    public int score() {
        return currentScore;
    }

  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Indica se o jogo terminou. Para este jogo, o fim acontece quando:
     *  - a grelha está completamente vazia ou já não há nenhuma coluna onde caiba uma peça inteira
     * @return true se o jogo já acabou, false caso contrário
     */
    public boolean finished() {
       
        //    termina quando a área de jogo está completamente vazia ou quando não existe nenhuma coluna onde ainda caiba uma peça.
        return gridIsEmpty() || !area.hasEnoughSpace(SIZE_OF_PIECE);
    }
    
  //--------------------------------------------------------------------------------------------------------------------
    
    /**
     * Representação textual do jogo. Mostra a grelha, a peça atual e, no fim, a pontuação.
     * @return texto com o estado do jogo e o score atual
     */
    public String toString() {
        // Usa a representação base (grelha + peça atual) e acrescenta a pontuação no fim.
        return super.toString()
                + "Score: " + currentScore + System.lineSeparator();
    }
}
