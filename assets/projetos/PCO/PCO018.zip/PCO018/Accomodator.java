
/**
 * Acomoda os símbolos numa sequência, tratando os buracos
 * representados pelo símbolo {@code nothing}. A forma como os
 * símbolos descem ou desaparecem depende da implementação concreta.
 *
 * @author Grupo 18 – Marta Cabral (64686), Camile Hasse (64178)
 *
 * @param seq sequência onde será feita a acomodação
 * @param nothing símbolo que representa um buraco/vazio
 *
 * @requires seq != null
 * @requires nothing != null
 */


public interface Accomodator {
    void accomodate(Symbol[] seq, Symbol nothing);
}
